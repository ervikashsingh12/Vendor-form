package com.fishersci.supplierexchange.bi.config;

import com.fishersci.supplierexchange.bi.api.controllers.ExceptionController;
import com.fishersci.supplierexchange.bi.api.controllers.JWTAuthEntryPoint;
import com.fishersci.supplierexchange.bi.api.filters.JWTFilter;
import com.fishersci.supplierexchange.bi.services.JWTService;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
@EnableWebSecurity
@RequiredArgsConstructor
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {
    private final JWTService jwtService;
    private final ExceptionController exceptionController;

    @Override
    protected void configure(HttpSecurity httpSecurity) throws Exception {
        httpSecurity
                // we don't need CSRF because our token is invulnerable
                .csrf().disable()

                .exceptionHandling().authenticationEntryPoint(exceptionController).and()

                // don't create session
                .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS).and()
                .authorizeRequests()
                .antMatchers("/actuator/**").permitAll()
                .anyRequest().authenticated();

        httpSecurity
                .addFilterBefore(new JWTFilter(jwtService, exceptionController), UsernamePasswordAuthenticationFilter.class);
        // disable page caching

        httpSecurity
                .headers()
                .frameOptions().sameOrigin()  // required to set for H2 else H2 Console will be blank.
                .cacheControl();
    }

}
