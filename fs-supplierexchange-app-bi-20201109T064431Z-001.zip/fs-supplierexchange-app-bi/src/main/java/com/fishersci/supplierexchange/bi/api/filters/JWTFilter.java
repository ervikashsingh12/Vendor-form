package com.fishersci.supplierexchange.bi.api.filters;

import com.fishersci.supplierexchange.bi.api.controllers.ExceptionController;
import com.fishersci.supplierexchange.bi.api.model.UserInfo;
import com.fishersci.supplierexchange.bi.services.JWTService;
import com.fishersci.supplierexchange.bi.utils.JWTException;
import io.jsonwebtoken.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Component
@Slf4j
public class JWTFilter extends OncePerRequestFilter {
    private final JWTService service;
    private ExceptionController errorHandler;

    @Autowired
    public JWTFilter(JWTService service, ExceptionController errorHandler) {
        this.service = service;
        this.errorHandler = errorHandler;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws ServletException, IOException {
     String jwt = request.getHeader("Authorization") == null? "": request.getHeader("Authorization");
     //  String jwt = "Bearer eyJhbGciOiJIUzUxMiJ9.eyJzdXBwbGllciI6eyJzdXBwbGllcklkIjoiZGMyOTI5NDctMTYyOS00MWYwLWFmZDktMjEyMDMwYjc3N2E1Iiwic3VwcGxpZXJOYW1lIjoiM00iLCJzdXBwbGllckd1aWRlUmVnaW9ucyI6WyJOQSJdLCJ0cmFuc3BvcnRhdGlvbkd1aWRlUmVnaW9ucyI6W10sInRpZXJOQSI6NiwidGllckVVIjoxLCJzbWYiOmZhbHNlLCJkaXN0cmlidXRpb25BZ3JlZW1lbnQiOmZhbHNlLCJzdXBwbGllckRlbGV0ZWQiOmZhbHNlLCJzdXBwbGllckFsaWFzZXMiOlsiVk4wMDA1NTc3NyIsIlZOMDAwMDcyMTciLCJWTjAwMDYxMzkwIiwiVk4wMDAwNzIyMCJdfSwidG9rZW5fZXhwaXJhdGlvbl9kYXRlIjoxNTcxODU5NTQxMDIyLCJ1c2VyIjp7InVzZXJJZCI6InRocmVlbXRlc3RlckBtYWlsaW5hdG9yLmNvbSIsImVtYWlsIjoiVGhyZWVNVGVzdGVyQG1haWxpbmF0b3IuY29tIiwidXNlclR5cGUiOiJmcy1leHRlcm5hbCIsInJlZ2lvbnMiOlsiTkEiLCJFVSJdLCJjb3VudHJpZXMiOlsiVVMiLCJDQSIsIkFUIiwiREUiLCJQVCIsIkJFIiwiSUUiLCJFUyIsIkRLIiwiSVQiLCJTRSIsIkZJIiwiTkwiLCJDSCIsIkZSIiwiTk8iLCJVSyJdLCJ3aWRnZXRzIjpbXSwiZmlyc3ROYW1lIjoiM00iLCJsYXN0TmFtZSI6IjNNIiwidGl0bGUiOiIzTSIsInN1cHBsaWVyUGVyZm9ybWFuY2UiOnRydWUsInByb2R1Y3RJbWFnZXMiOmZhbHNlLCJwcmljZVJvbGwiOnRydWUsInVzZXJEZWxldGVkIjpmYWxzZSwiYWN0aXZlIjp0cnVlLCJuYW1lIjoiM00sIDNNIiwibGFuZ1ByZWYiOiJlbiIsImNsb25pbmdCeSI6IiIsImNsb25pbmciOmZhbHNlfX0.lDuLT8QeFbfbRxpoMSpQqYhrHi1Pqln4S3ZJCBapX9SxX_MPcPwefk1oJGSaJs94YxroxQfeDR2qNlTeQ-sfjg";
        String url = request.getRequestURL().toString();
        if(url.contains("actuator")) {
            chain.doFilter(request, response);
            return;
        }
        //TODO: refactor this function
        try {
            if (!jwt.equals("") && this.service.isActive(jwt.substring(7))) {
                String token = jwt.substring(7);
                List<SimpleGrantedAuthority> authorities = new ArrayList<>();

                authorities.add(new SimpleGrantedAuthority("ROLE_USER"));

                UserInfo userInfo = this.service.getUserFromToken(token);
                UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(userInfo, null, authorities);
                authentication.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));

                // Setting UserInfo in security context
                // in Controllers use request.getUserPrincipal() to access UserInfo user
                SecurityContextHolder.getContext().setAuthentication(authentication);

                chain.doFilter(request, response);
                return;
            }
        } catch (ExpiredJwtException | UnsupportedJwtException | MalformedJwtException |SignatureException | IllegalArgumentException e) {
            request.setAttribute("Exception", new JWTException(e.getMessage()));
            response.sendError(HttpServletResponse.SC_NOT_ACCEPTABLE, "Malformed Jwt" + e.getMessage());
            return;
        }
        catch(Exception e ){
        	System.out.println(e);
        	
        }
        request.setAttribute("Exception", new JWTException("Not Authorized"));
        response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Not Authorized");
    }

    @Override
    public void destroy() {
        log.warn("Destructing filter :{}", this);
    }
}
