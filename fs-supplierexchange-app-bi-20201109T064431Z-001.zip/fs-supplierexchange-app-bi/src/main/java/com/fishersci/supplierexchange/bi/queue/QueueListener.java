package com.fishersci.supplierexchange.bi.queue;

import java.util.Iterator;
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Component;

import com.amazonaws.services.sqs.AmazonSQS;
import com.amazonaws.services.sqs.AmazonSQSClientBuilder;
import com.amazonaws.services.sqs.model.DeleteMessageRequest;
import com.amazonaws.services.sqs.model.Message;
import com.amazonaws.services.sqs.model.ReceiveMessageRequest;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fishersci.supplierexchange.bi.services.DataExtractService;
import com.fishersci.supplierexchange.bi.utils.MailUtil;

@Component
public class QueueListener implements CommandLineRunner {
	private static final Log LOG = LogFactory.getLog(QueueListener.class);

	@Autowired
	private DataExtractService dataExtractService;

	@Resource(name = "jobspoolexecutor")
	private ThreadPoolTaskExecutor taskExecutorjobs;

	@Value("${sqs.queueurl}")
	String queueurl;

	@Value("${invoice.file.size:}")
	String fileSize;

	@Autowired
	private MailUtil mailUtil;

	@Override
	public void run(String... args) {

		AmazonSQS sqs = AmazonSQSClientBuilder.defaultClient();

		if (queueurl.length() > 0) {
			LOG.info("start Queue listenner");
			while (true) {
				try {
					// Receive messages
					if (taskExecutorjobs.getActiveCount() <= taskExecutorjobs.getCorePoolSize()) {
						ReceiveMessageRequest receiveMessageRequest = new ReceiveMessageRequest(queueurl);
						List<Message> messages = sqs.receiveMessage(receiveMessageRequest).getMessages();
						for (Message message : messages) {
							LOG.info("received Message: " + message.getBody());
							// Convert the message into JSON object
							try {
								String jsonStr = message.getBody();

								ObjectMapper mapper = new ObjectMapper();
								JsonNode json = mapper.readTree(jsonStr);

								JsonNode records = json.get("Records");
								Iterator<JsonNode> elements = records.elements();
								String fileName = "";
								String bucketName = "";
								long fileSize = 0;
								while (elements.hasNext()) {
									JsonNode record = elements.next();
									JsonNode s3 = record.get("s3");
									JsonNode object = s3.get("object");
									JsonNode key = object.get("key");
									fileName = key.asText();

									JsonNode size = object.get("size");

									fileSize = size.asLong();
									JsonNode bucket = s3.get("bucket");
									JsonNode name = bucket.get("name");
									bucketName = name.asText();
								}

								String messageReceiptHandle = message.getReceiptHandle();
								sqs.deleteMessage(new DeleteMessageRequest(queueurl, messageReceiptHandle));
								// Download the file from s3 bucket
								// comment for development if(fileSize < 60000 * 1024) { // 1kb = 1024b
								//if(fileSize < 1 * 1024) { // 1kb = 1024b
								if(fileSize < 60000 * 1024) {
									LOG.info("fileSize is too small, hence could not insert into db.");
									mailUtil.sendWarningMsg(fileName); // file size is too small scenario
								} else {
									LOG.info(fileName + " -> fileSizse is " + fileSize + " bytes");
									dataExtractService.downloadCSVFile(bucketName, fileName);
								}
							} catch (Exception e) {
								LOG.error(e.getMessage(), e);
							} finally {
								String messageReceiptHandle = message.getReceiptHandle();
								sqs.deleteMessage(new DeleteMessageRequest(queueurl, messageReceiptHandle));
							}
						}
					} else {
						Thread.sleep(5000);
					}
				} catch (Exception e) {
					LOG.error(e.getMessage(), e);
				}
			}
		}

	}
}
