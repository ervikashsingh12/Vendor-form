package com.fishersci.supplierexchange.bi.services;

import com.fishersci.supplierexchange.bi.api.model.InvoiceDTO;
import com.fishersci.supplierexchange.bi.domain.Invoice;

import java.util.List;

public interface InvoiceService {
    List<Invoice> getAllInvoices();
    InvoiceDTO getInvoiceByFisherID(String id);
}
