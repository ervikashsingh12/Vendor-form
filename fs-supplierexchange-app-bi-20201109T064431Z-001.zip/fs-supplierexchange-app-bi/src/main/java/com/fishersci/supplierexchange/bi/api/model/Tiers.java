package com.fishersci.supplierexchange.bi.api.model;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public enum Tiers {
    TIER1(Arrays.asList("Content Scorecard", "Zip Code", "Complaints Tracker", "Dead and Excess", "Category", "Segment", "Key Supplier Calendar", "Metrics", "Demand Forecast", "Scorecard", "Key Initiative Tracker", "Sales Manager", "Opportunity", "Pipeline")),
    TIER2(Arrays.asList("Content Scorecard", "Zip Code", "Complaints Tracker", "Dead and Excess", "Category", "Segment", "Key Supplier Calendar", "Metrics", "Demand Forecast", "Scorecard")),
    TIER3(Arrays.asList("Content Scorecard", "Zip Code", "Complaints Tracker", "Dead and Excess")),
    TIER4(Arrays.asList("Content Scorecard", "Zip Code", "Complaints Tracker"));

    private List<String> reportTypes;

    Tiers(List<String>reportTypes){
        this.reportTypes = reportTypes;
    }

    public List<String> getReportTypes(){
        return reportTypes;
    }
}
