package com.fishersci.supplierexchange.bi.services;

import com.fishersci.supplierexchange.bi.api.mapper.InvoiceMapper;
import com.fishersci.supplierexchange.bi.api.model.InvoiceDTO;
import com.fishersci.supplierexchange.bi.domain.Invoice;

import java.util.List;

public class InvoiceServiceImpl implements InvoiceService {
    private final InvoiceMapper invoiceMapper;

    public InvoiceServiceImpl(InvoiceMapper invoiceMapper) {
        this.invoiceMapper = invoiceMapper;
    }

    @Override
    public List<Invoice> getAllInvoices() {
        return null;
    }

    @Override
    public InvoiceDTO getInvoiceByFisherID(String id) {
        return null;
    }
}