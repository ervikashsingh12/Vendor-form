package com.fishersci.supplierexchange.bi.api.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.data.annotation.Transient;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@RequiredArgsConstructor
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class UserInfo implements UserDetailsService {

	private Supplier supplier;
	private User user;

	@JsonProperty("token_expiration_date")
	private Date tokenExpirationDate;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		return null;
	}

	@Data
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class Supplier {
		public String supplierName;
		private Boolean distributionAgreement;
		@Transient
		public List<Region> supplierGuideRegions;
		@Transient
		public List<Region> transportationGuideRegions;
		public String supplierId;
		public List<String> supplierAliases;
		public int tierNA;
		public int tierEU;
		public Boolean smf;
		public Boolean supplierDeleted;
		public LocalDateTime updatedDt;
	}


	@Data
	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class User {
		private String userId;
		private UserType userType;
		private List<Region> regions;
		private List<String> countries;
		private List<String> widgets;
		private String firstName;
		private String lastName;
		private String title;
		private Boolean supplierPerformance;
		private Boolean productImages;
		private String email;
		private Boolean priceRoll;
		private Boolean userDeleted;
		private Boolean active;
		private String name;
		private String cloningBy;
		private Boolean cloning;
		@Transient
		private String langPref;
	}


	public enum Region {
		NA, EU
	}

	//    @AllArgsConstructor//(onConstructor = @__(@JsonCreator))
	public enum UserType {
		@JsonProperty("fs-category-owner")
		CATEGORY_OWNER,
		@JsonProperty("fs-admin")
		ADMIN,
		@JsonProperty("fs-external")
		EXTERNAL,
		@JsonProperty("fs-internal")
		INTERNAL
	}

	public boolean canAccessPerformance() {
		return (user.getWidgets().contains("SP") || user.getWidgets().contains("allWidgets"))
				&& (user.userType == UserType.CATEGORY_OWNER || user.userType == UserType.ADMIN) ;
	}

	public List<String> reportsForTiers() {
		ArrayList<String> reportTypes = new ArrayList<>();
		switch (supplier.tierNA) {
			case 1:
				return Tiers.TIER1.getReportTypes();
			case 2:
				return Tiers.TIER2.getReportTypes();
			case 3:
				return Tiers.TIER3.getReportTypes();
			case 4:
				return Tiers.TIER4.getReportTypes();
		}
		return reportTypes;
	}
}

