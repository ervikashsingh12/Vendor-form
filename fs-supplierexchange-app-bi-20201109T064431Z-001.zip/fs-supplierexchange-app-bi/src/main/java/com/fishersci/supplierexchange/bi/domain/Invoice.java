package com.fishersci.supplierexchange.bi.domain;

import java.math.BigDecimal;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@Table(name="bi_invoices")
@NoArgsConstructor
public class Invoice {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String fisherVendorNumber;
    private String invoiceNumber;
    
    @Column(name = "invoice_date", columnDefinition = "DATE")
    private Date invoiceDate;
    
    private String invoiceDescription;
    private String invoiceType;
    private String poNumber;
    private Character invoiceStatus;
    private BigDecimal invoiceAmount;
    private BigDecimal invoiceAmountError;
    private Integer lineNumber;
    private String partNumber;
    private String vendorPartNumber;
    private String uom;
    private BigDecimal orderQty;
    private BigDecimal qtyReceived;
    private BigDecimal qtyPreviouslyInvoiced;
    private Character lineStatus;
    private BigDecimal qtyInvoiced;
    private BigDecimal lineAmountError;
    private String errorMessageConcat;
    
    public String paymentTerm;
    @Column(name="invoice_expected_date", columnDefinition="DATE")
    public Date invoiceExpectedDate;
    
    @Column(name="invoice_paid_date", columnDefinition="DATE")
    public Date invoicePaidDate;
    
    @Column(name="payment_number")
	public String paymentNumber;

 
}
