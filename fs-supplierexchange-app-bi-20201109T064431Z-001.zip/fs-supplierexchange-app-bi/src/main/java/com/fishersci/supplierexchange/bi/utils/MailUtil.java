package com.fishersci.supplierexchange.bi.utils;

import java.util.List;

import javax.mail.internet.MimeMessage;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;


@Component
@Slf4j
@RequiredArgsConstructor
public class MailUtil {

	private final JavaMailSender sender;

	@Value("${mail.invoice.from}")
	String from;

	@Value("${mail.invoice.to}")
	String to;

	public String sendSuccessMsg(String fileName) {
		return this.send(from, to, "AP vendor invoices data loaded successfully", null, "The file <b>" + fileName + "</b> for AP Vendor invoices is successfully loaded.");
	}
	
	public String sendExceptionMsg(List<String> rows, String fileName) {
		
		StringBuilder sb = new StringBuilder();
		for(String r: rows) {
			sb.append(r);
			sb.append("</br>");
		}
		
		return this.send(from, to, "Maximum number of Exceptions occured in . " + fileName, null, "The fallowing Exceptions are occured in file <b>" + fileName + "</b>"+"\n" +sb.toString());
	}
	
	public String sendWarningMsg(String fileName) {
		return this.send(from, to, "File is too small to upload data", null, "The Requested AP vendor invoice file <b>" + fileName + "</b> is  too small to process and upload data");
	}
	public String send(String from, String to, String subject, String cc, String body) {
		try {
			MimeMessage message = sender.createMimeMessage();
			message.setContent(body, "text/html");
			MimeMessageHelper helper = new MimeMessageHelper(message, true);
			helper.setTo(to);
			helper.setFrom(from);
			if (StringUtils.isNotEmpty(subject)) {
				helper.setSubject(subject);
			}
			if (StringUtils.isNotEmpty(cc)) {
				helper.setCc(cc);
			}
			if (StringUtils.isNotEmpty(body)) {
				helper.setText(body, true);
			}

			sender.send(message);
			return "Sent";
		} catch (Exception e) {
			log.error("Exception thrown during Send Mail in CommApp:", e);
			return "Failed";
		}
	}
}
