package com.fishersci.supplierexchange.bi.utils;
public class JWTException extends Exception{

    public JWTException(String message){
        super(message);
    }

}
