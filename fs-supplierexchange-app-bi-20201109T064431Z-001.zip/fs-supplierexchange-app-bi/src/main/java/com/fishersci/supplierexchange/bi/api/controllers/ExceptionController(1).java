package com.fishersci.supplierexchange.bi.api.controllers;
import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.HandlerExceptionResolver;

import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;


@RestController
@ControllerAdvice
public class ExceptionController implements ErrorController, AuthenticationEntryPoint {
    private static final String PATH = "/error";
    private HandlerExceptionResolver resolver;

    @ExceptionHandler({Exception.class})
    @RequestMapping(value = PATH)
    public HashMap<Object,Object> handleException(ServletRequest request, ServletResponse response, AuthenticationException authException) {
        HttpServletRequest req = (HttpServletRequest) request;
        Exception ex = (Exception) req.getAttribute("Exception");
        HashMap<Object, Object> responseObject = new HashMap<>();
        responseObject.put("Error", ex.getMessage());
        return responseObject;
    }

    @Override
    public String getErrorPath() {
       return PATH;
    }

    @Override
    public void commence(HttpServletRequest request, HttpServletResponse response, AuthenticationException authException) throws IOException, ServletException {
        handleException(request, response, authException);
    }
}
