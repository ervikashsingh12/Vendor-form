package com.fishersci.supplierexchange.bi.repositories;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.rest.core.annotation.RestResource;
import org.springframework.stereotype.Repository;

import com.fishersci.supplierexchange.bi.domain.InvoiceStaging;

@Repository
public interface InvoiceStagingRepository extends PagingAndSortingRepository<InvoiceStaging, Long> {

    @RestResource(exported = false)
    @Override
    <S extends InvoiceStaging> S save(S entity);

    @RestResource(exported = false)
    @Override
    <S extends InvoiceStaging> Iterable<S> saveAll(Iterable<S> entities);
    
    @Query(
            value = "truncate table public.bi_invoices_staging",
            nativeQuery = true
    )
    void truncateTable();
}
