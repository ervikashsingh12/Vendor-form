package com.fishersci.supplierexchange.bi.api.model;

public class Category {
}
