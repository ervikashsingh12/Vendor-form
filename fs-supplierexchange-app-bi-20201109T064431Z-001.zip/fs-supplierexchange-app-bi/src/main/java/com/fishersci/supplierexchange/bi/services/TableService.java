package com.fishersci.supplierexchange.bi.services;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import com.fishersci.supplierexchange.bi.api.model.UserInfo;
import com.fishersci.supplierexchange.bi.domain.Invoice;
import com.fishersci.supplierexchange.bi.repositories.InvoiceRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@RequiredArgsConstructor
@Transactional
public class TableService {

    @Autowired
    private  InvoiceRepository invoiceRepository ;
    
    
    public Page<Invoice> getSearchCriteria(String fuzzyNumber, String invoiceDate, String invoiceType,
			Character invoiceStatus, String errorMessageConcat,Pageable pageable) {
		if (fuzzyNumber.length() < 1)
			fuzzyNumber = null;
		if (invoiceType.length() < 1)
			invoiceType = null;
		if (errorMessageConcat.length() < 1)
			errorMessageConcat = null;
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		Date date = null;
		if (invoiceDate.length() > 0) {
			try {
				date = formatter.parse(invoiceDate);
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
		if (invoiceStatus !=null && 'p' == Character.toLowerCase(invoiceStatus)) {
			return invoiceRepository.findBysearchCriteria(fuzzyNumber, date, invoiceType, invoiceStatus,
					errorMessageConcat,pageable);
		} else {
			return invoiceRepository.findBysearchCriteriaWithoutDateRange(fuzzyNumber, date, invoiceType, invoiceStatus,
					errorMessageConcat,pageable);
		}
		}
 
    public String generateCsvData(Character invoiceStatus) {
        UserInfo user = new UserInfo();
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (!(auth instanceof AnonymousAuthenticationToken)) {
            user = (UserInfo) auth.getPrincipal();
        }
        StringBuilder sb = new StringBuilder("fisher_vendor_number,invoice_number, invoice_date, invoice_description, invoice_type, po_number, invoice_status," +
                "invoice_amount, invoice_amount_error, line_number, part_number, vendor_part_number, uom, order_qty, qty_received, qty_previously_invoiced, line_status, qty_invoiced," +
                "line_amount_error, error_message,payment_term,invoice_expected_date,invoice_paid_date, payment_number "+ System.lineSeparator());
        List<Invoice> invoiceList = new ArrayList<>();
        for (String fvn: user.getSupplier().getSupplierAliases()) {
            invoiceList.addAll(invoiceRepository.findByFisherVendorNumberAndInvoiceStatus(fvn,invoiceStatus));
            if(invoiceStatus=='O') {
            invoiceList.addAll(invoiceRepository.findByFisherVendorNumberAndInvoiceStatus(fvn,'E'));
        	}
        }
        for(Invoice inv: invoiceList) {
            sb.append(inv.getFisherVendorNumber() != null ? inv.getFisherVendorNumber() : "" );
            sb.append(",");
            sb.append(inv.getInvoiceNumber() != null ? inv.getInvoiceNumber() : "" );
            sb.append(",");
            sb.append(inv.getInvoiceDate() != null ? inv.getInvoiceDate() : "" );
            sb.append(",");
            sb.append(inv.getInvoiceDescription() != null ? inv.getInvoiceDescription() : "" );
            sb.append(",");
            sb.append(inv.getInvoiceType() != null ? inv.getInvoiceType() : "" );
            sb.append(",");
            sb.append(inv.getPoNumber() != null ? inv.getPoNumber() : "" );
            sb.append(",");
            sb.append(inv.getInvoiceStatus() != null ? inv.getInvoiceStatus() : "" );
            sb.append(",");
            sb.append(inv.getInvoiceAmount() != null ? inv.getInvoiceAmount() : "" );
            sb.append(",");
            sb.append(inv.getInvoiceAmountError() != null ? inv.getInvoiceAmountError() : "" );
            sb.append(",");
            sb.append(inv.getLineNumber() != null ? inv.getLineNumber() : "" );
            sb.append(",");
            sb.append(inv.getPartNumber() != null ? inv.getPartNumber() : "" );
            sb.append(",");
            sb.append(inv.getVendorPartNumber() != null ? inv.getVendorPartNumber() : "" );
            sb.append(",");
            sb.append(inv.getUom() != null ? inv.getUom() : "" );
            sb.append(",");
            sb.append(inv.getOrderQty() != null ? inv.getOrderQty() : "" );
            sb.append(",");
            sb.append(inv.getQtyReceived() != null ? inv.getQtyReceived() : "" );
            sb.append(",");
            sb.append(inv.getQtyPreviouslyInvoiced() != null ? inv.getQtyPreviouslyInvoiced() : "" );
            sb.append(",");
            sb.append(inv.getLineStatus() != null ? inv.getLineStatus() : "" );
            sb.append(",");
            sb.append(inv.getQtyInvoiced() != null ? inv.getQtyInvoiced() : "" );
            sb.append(",");
            sb.append(inv.getLineAmountError() != null ? inv.getLineAmountError() : "" );
            sb.append(",");
            sb.append(inv.getErrorMessageConcat() != null ? inv.getErrorMessageConcat() : "" );
            sb.append(",");
            sb.append(inv.paymentTerm != null ? inv.paymentTerm : "" );
            sb.append(",");
            sb.append(inv.invoiceExpectedDate != null ? inv.invoiceExpectedDate : "" );
            sb.append(",");
            sb.append(inv.invoicePaidDate != null ? inv.invoicePaidDate : "" );
            sb.append(System.lineSeparator());
            sb.append(inv.getPaymentNumber() != null ? inv.getPaymentNumber() : "" );
            sb.append(",");
            
        }
        return sb.toString();

    }

	
}