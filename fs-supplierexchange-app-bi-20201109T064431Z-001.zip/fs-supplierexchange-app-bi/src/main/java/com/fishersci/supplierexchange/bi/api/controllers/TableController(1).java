package com.fishersci.supplierexchange.bi.api.controllers;

import com.fishersci.supplierexchange.bi.domain.Invoice;
import com.fishersci.supplierexchange.bi.services.DataExtractService;
import com.fishersci.supplierexchange.bi.services.TableService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.text.ParseException;
import javax.servlet.http.HttpServletResponse;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequiredArgsConstructor
@Slf4j
public class TableController {
    private final TableService tableService ;
    @Autowired
    DataExtractService objData;
    /**
     * Returns csv file which contains invoice data for all supplier aliases
     * @param response
     * @return
     */
    @GetMapping(value = "/invoices/export", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
    public String ExtractInvoiceData(HttpServletResponse response,@RequestParam("invoiceStatus") Character invoiceStatus) {
        String csvFile = tableService.generateCsvData(invoiceStatus);
        response.setHeader("Content-Disposition", "attachment;filename=\"" + "Invoices" + ".csv\"");
        return csvFile;
    }
//    @GetMapping(value = "/invoices/CSVPortTesting", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
//    public String CSVPortTesting() throws IOException {
//    	objData.downloadCSVFile("vikash", "Singh");
//        return "Success";
//    }
    
    
    @GetMapping(value = "/invoices/search/searchCriteria", produces = MediaType.APPLICATION_JSON_VALUE)
    public Page<Invoice> ExtractSearchCriteriaData(@RequestParam("fuzzyNumber") String fuzzyNumber,
    		@RequestParam("invoiceDate") String invoiceDate,@RequestParam("invoiceType") String invoiceType,
    		@RequestParam("invoiceStatus") Character invoiceStatus,@RequestParam("errorMessageConcat") String errorMessageConcat,
    		 @PageableDefault(page = 0, size = 20) org.springframework.data.domain.Pageable pageable) throws ParseException {
      
        return tableService.getSearchCriteria(fuzzyNumber,invoiceDate,invoiceType,invoiceStatus,errorMessageConcat,pageable);
    }
}
