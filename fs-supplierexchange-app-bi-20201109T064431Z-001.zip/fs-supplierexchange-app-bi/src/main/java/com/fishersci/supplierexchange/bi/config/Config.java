package com.fishersci.supplierexchange.bi.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

@EnableAsync
@Configuration
public class Config {

	@Bean(name = "jobspoolexecutor")
	public ThreadPoolTaskExecutor taskExecutorjobs() {
		ThreadPoolTaskExecutor pool = new ThreadPoolTaskExecutor();
		pool.setCorePoolSize(Integer.parseInt("2"));
		pool.setMaxPoolSize(Integer.parseInt("3"));
		pool.setQueueCapacity(Integer.parseInt("3"));
		pool.setThreadNamePrefix("SQS");
		pool.setWaitForTasksToCompleteOnShutdown(true);
		return pool;
	}
}
