package com.fishersci.supplierexchange.bi.repositories;

import java.sql.Date;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RestResource;
import org.springframework.stereotype.Repository;
import java.util.List;
import com.fishersci.supplierexchange.bi.domain.Invoice;


@Repository
public interface InvoiceRepository extends PagingAndSortingRepository<Invoice, Long>{

    @RestResource(exported = false)
    @Override
    <S extends Invoice> S save(S entity);

    @RestResource(exported = false)
    @Override
    <S extends Invoice> Iterable<S> saveAll(Iterable<S> entities);

    @RestResource(exported = false)
    @Override
    Optional<Invoice> findById(Long aLong);

    @RestResource(exported = false)
    @Override
    boolean existsById(Long aLong);

    // did not need to override findAll() and findAll(Sort sort).. not sure why?
    @Override
    @Query("select inv from Invoice inv where fisherVendorNumber in ?#{ principal?.user.regions.toString().contains('NA') ? principal?.supplier.supplierAliases :  null }")
    Page<Invoice> findAll(Pageable pageable);

//    @RestResource(path = "searchCriteria", rel="searchCriteria")
//    @Query("select inv from Invoice inv " +
//            "where fisherVendorNumber in ?#{ principal?.user.regions.toString().contains('NA') ? principal?.supplier.supplierAliases :  null } " +
//            "and (cast(:fuzzyNumber as text) is null or cast(:fuzzyNumber as text) in (inv.fisherVendorNumber, inv.invoiceNumber, inv.poNumber)) " +
//            "and (cast(:invoiceDate as text) is null or month(inv.invoiceDate) = month( cast( cast(:invoiceDate as text) as date )) ) " +
//            "and (cast(:invoiceDate as text) is null or year(inv.invoiceDate) = year( cast( cast(:invoiceDate as text) as date )) ) "  +
//            "and (cast(:invoiceType as text) is null or :invoiceType = inv.invoiceType) " +
//            "and (cast(:invoiceStatus as text) is null or :invoiceStatus = inv.invoiceStatus) " +
//            "and (cast(:errorMessageConcat as text) is null or :errorMessageConcat = inv.errorMessageConcat)")
//    Page<Invoice> searchCriteria(
//            @Param("fuzzyNumber") String fuzzyNumber,
//            @Param("invoiceDate") Date invoiceDate,
//            @Param("invoiceType") String invoiceType,
//            @Param("invoiceStatus") Character invoiceStatus,
//            @Param("errorMessageConcat") String errorMessageConcat,
//            Pageable pageable);
    
    @Query("select inv from Invoice inv " +
    		"where fisherVendorNumber in ?#{ principal?.user.regions.toString().contains('NA') ? principal?.supplier.supplierAliases :  null } " +
            "and (cast(:fuzzyNumber as text) is null or cast(:fuzzyNumber as text) in (inv.fisherVendorNumber, inv.invoiceNumber, inv.poNumber)) " +
            "and (cast(:invoiceDate as text) is null or month(inv.invoiceDate) = month( cast( cast(:invoiceDate as text) as date )) ) " +
            "and (cast(:invoiceDate as text) is null or year(inv.invoiceDate) = year( cast( cast(:invoiceDate as text) as date )) ) "  +
            "and (cast(:invoiceType as text) is null or :invoiceType = inv.invoiceType) " +
            "and (cast(:invoiceStatus as text) is null or :invoiceStatus = inv.invoiceStatus) " +
            "and (cast(:errorMessageConcat as text) is null or :errorMessageConcat = inv.errorMessageConcat)")
    Page<Invoice> findBysearchCriteriaWithoutDateRange(
    		@Param("fuzzyNumber")  String fuzzyNumber,
    		@Param("invoiceDate") java.util.Date invoiceDate,
    		 @Param("invoiceType") String invoiceType,
    		 @Param("invoiceStatus") Character invoiceStatus,
            @Param("errorMessageConcat")  String errorMessageConcat,
            Pageable pageable);
    
    @Query("select inv from Invoice inv " +
            "where fisherVendorNumber in ?#{ principal?.user.regions.toString().contains('NA') ? principal?.supplier.supplierAliases :  null } " +
            "and (cast(:fuzzyNumber as text) is null or cast(:fuzzyNumber as text) in (inv.fisherVendorNumber, inv.invoiceNumber, inv.poNumber)) " +
           "and (cast(:invoiceDate as text) is null or (inv.invoiceDate) >= ( cast( cast(:invoiceDate as text) as date )) ) "  +
            "and (cast(:invoiceType as text) is null or :invoiceType = inv.invoiceType) " +
            "and (cast(:invoiceStatus as text) is null or :invoiceStatus = inv.invoiceStatus) " +
            "and (cast(:errorMessageConcat as text) is null or :errorMessageConcat = inv.errorMessageConcat)")
    Page<Invoice> findBysearchCriteria(
    		@Param("fuzzyNumber")  String fuzzyNumber,
    		@Param("invoiceDate") java.util.Date invoiceDate,
    		 @Param("invoiceType") String invoiceType,
    		 @Param("invoiceStatus") Character invoiceStatus,
            @Param("errorMessageConcat")  String errorMessageConcat,
            Pageable pageable);
    
    @RestResource(exported = false)
    @Override
    Iterable<Invoice> findAllById(Iterable<Long> longs);

    List<Invoice> findByFisherVendorNumberAndInvoiceStatus(String fisherVendorNumber, Character invoiceStatus);

    @RestResource(exported = false)
    @Override
    public void deleteById(Long aLong);

    @RestResource(exported = false)
    @Override
    void delete(Invoice entity);

    @RestResource(exported = false)
    @Override
    void deleteAll(Iterable<? extends Invoice> entities);

    @Query(
            value = "truncate table public.bi_invoices",
            nativeQuery = true
    )
    void truncateTable();
    
    @Query(
            value = "WITH cte AS (SELECT id,ctid,invoice_number,line_number,\r\n" + 
            		"ROW_NUMBER() OVER (PARTITION BY invoice_number,line_number\r\n" + 
            		"ORDER BY invoice_number, line_number,id desc) row_num FROM bi_invoices)\r\n" + 
            		"DELETE FROM bi_invoices USING cte WHERE cte.row_num > 1 AND cte.ctid = bi_invoices.ctid",
            nativeQuery = true
    )
    void removeDuplicateFromTable();
    
}
