package com.fishersci.supplierexchange.bi.services;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fishersci.supplierexchange.bi.api.model.UserInfo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.*;

import io.jsonwebtoken.*;

@Service
@Slf4j
public class JWTService {

    private final String tokenKey;
    private final ObjectMapper objectMapper;


    public JWTService(@Value("${jwt.secret}") String tokenKey) {
        objectMapper = new ObjectMapper();
        this.tokenKey = tokenKey;
    }

    private Map<String, Object> generateSampleClaims() {
        Map<String, Object> tokenData = new HashMap<>();

        Map<String, Object> user = new HashMap<>();
        List<String> widgets = new ArrayList<>();
        List<String> regions = new ArrayList<>();
        Collections.addAll(widgets,      "allWidgets", "AP", "NP", "MS", "PI", "SC", "SP");
        Collections.addAll(regions, "NA", "EU");
        user.put("email", "test@gmail.com");
        user.put("userType", "fs-category-owner");
        user.put("widgets", widgets);
        user.put("regions", regions);

        Map<String, Object> supplier = new HashMap<>();
        Map<String, Object> enableSupplierGuide = new HashMap<>();
        Map<String, Object> enableTransportationGuide = new HashMap<>();
        List<String> supplierRegions = new ArrayList<>();
        List<String> transportRegions = new ArrayList<>();
        List<String> supplierAliasList = new ArrayList<>();

        supplier.put("supplierId","03bc69b3-530f-40af-92fd-50324862fc9c");
        supplier.put("supplierName", "Corning Jim");
        Collections.addAll(supplierRegions, "NA", "EU");
        Collections.addAll(transportRegions, "NA", "EU");
        Collections.addAll(supplierAliasList, "VN00000003", "VN00030672");
        supplier.put("supplierAliases", supplierAliasList);
        supplier.put("enableSupplierGuide", supplierRegions);
        supplier.put("enableTransportationGuide", transportRegions);
        Date date = new Date();
        date.setTime(LocalDate.now().plusDays(20L).toEpochDay());
        tokenData.put("user", user);
        tokenData.put("supplier", supplier);
        tokenData.put("token_expiration_date", date.getTime());
        return tokenData;
    }

    public Map<String, Object> generateSampleClaims(List<String> supplierAliases, List<String> regions) {
        Map<String, Object> tokenData = new HashMap<>();

        Map<String, Object> user = new HashMap<>();
        List<String> widgets = new ArrayList<>();
        Collections.addAll(widgets,      "allWidgets", "AP", "NP", "MS", "PI", "SC", "SP");
        user.put("email", "test@gmail.com");
        user.put("userType", "fs-category-owner");
        user.put("widgets", widgets);
        user.put("regions", regions);
        user.put("active", true);
        user.put("supplierPerformance", false);
        user.put("userDeleted", false);
        user.put("name", "test name");

        Map<String, Object> supplier = new HashMap<>();
        Map<String, Object> enableSupplierGuide = new HashMap<>();
        Map<String, Object> enableTransportationGuide = new HashMap<>();
        List<String> supplierRegions = new ArrayList<>();
        List<String> transportRegions = new ArrayList<>();

        supplier.put("supplierId","03bc69b3-530f-40af-92fd-50324862fc9c");
        supplier.put("distributionAgreement", true);
        supplier.put("supplierName", "Corning Jim");
        Collections.addAll(supplierRegions, "NA", "EU");
        Collections.addAll(transportRegions, "NA", "EU");
        enableSupplierGuide.put("regions", supplierRegions);
        enableTransportationGuide.put("regions", transportRegions);
        supplier.put("supplierAliases", supplierAliases);
        supplier.put("supplierGuideRegions", supplierRegions);
        supplier.put("transportationGuideRegions", transportRegions);
        Date date = new Date();
        date.setTime(LocalDate.now().plusDays(20L).toEpochDay());
        tokenData.put("user", user);
        tokenData.put("supplier", supplier);
        tokenData.put("token_expiration_date", date.getTime());
        return tokenData;
    }

    public String generateToken(UserInfo userInfo) {
        Map<String, Object> userMap = new HashMap<>();
        if(userInfo == null){
            userMap = generateSampleClaims();
        }else {
            userMap.put("supplier",objectMapper.convertValue(userInfo.getSupplier(), Map.class));
            userMap.put("user", objectMapper.convertValue(userInfo.getUser(), Map.class));
            userMap.put("token_expiration_date", userInfo.getTokenExpirationDate());
        }
        Map<String, Object> tokenData = new HashMap<>();

        tokenData.put("userInfo", userMap);
        JwtBuilder builder = Jwts.builder();
        builder.setClaims(tokenData);
        return builder.signWith(SignatureAlgorithm.HS512, tokenKey.getBytes(StandardCharsets.UTF_8)).compact();
    }

    public Jws<Claims> parseToken(final String token) throws ExpiredJwtException, UnsupportedJwtException, MalformedJwtException, SignatureException, IllegalArgumentException {
        if (token != null) {
            return Jwts.parser().setSigningKey(tokenKey.getBytes(StandardCharsets.UTF_8)).parseClaimsJws(token);
        }
        return null;
    }

    public boolean isActive(final String token) {
        UserInfo user = this.getUserFromToken(token);
        return user.getUser().getActive();
    }

    public UserInfo getUserFromToken(final String token) throws ExpiredJwtException, UnsupportedJwtException, MalformedJwtException, SignatureException, IllegalArgumentException {
        // parse token to retrieve payload claims
        final Jws<Claims> tokenData = parseToken(token);
        Map<String, Object> claims = getClaimsFromToken(tokenData);

        //use jackson to convert claims to custom user object
        objectMapper.configure(DeserializationFeature.UNWRAP_ROOT_VALUE, true);
        return objectMapper.convertValue(claims, UserInfo.class);
    }

    private Map<String, Object> getClaimsFromToken(final Jws<Claims> tokenData) {
        if (tokenData != null) {
            return tokenData.getBody();
        }
        return null;
    }

}
