package com.fishersci.supplierexchange.bi.services;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import javax.persistence.Column;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.S3Object;
import com.fishersci.supplierexchange.bi.domain.Invoice;
import com.fishersci.supplierexchange.bi.domain.InvoiceStaging;
import com.fishersci.supplierexchange.bi.repositories.InvoiceRepository;
import com.fishersci.supplierexchange.bi.repositories.InvoiceStagingRepository;
import com.fishersci.supplierexchange.bi.utils.MailUtil;

@Service
public class DataExtractService {

	private static final Log LOG = LogFactory.getLog(DataExtractService.class);
	
	@Autowired
	private MailUtil mailUtil;

	@Autowired
	private InvoiceStagingRepository invoiceStagingRepo;

	@Autowired
	private InvoiceRepository invoiceRepo;
	
	@Value("${mail.invoice.from}")
	String from;

	@Value("${mail.invoice.to}")
	String to;

	private List<String> invoiceStatusList = Arrays.asList("O", "E","P");

	/**
	 * Download the file from s3 bucket and insert into db
	 * 
	 * @param bucketName
	 * @param key
	 * @throws IOException
	 */
	public void downloadCSVFile(String bucketName, String key) throws IOException {
		String clientRegion = "us-east-1";

		S3Object fullObject = null, objectPortion = null, headerOverrideObject = null;
		try {
			AmazonS3 s3Client = AmazonS3ClientBuilder.standard().withRegion(clientRegion).build();
			fullObject = s3Client.getObject(new GetObjectRequest(bucketName, key));
			List<String> dataList = populateData(fullObject.getObjectContent());
		   //System.out.println(dataList.size());
//			
//			File initialFile = new File("C:\\\\Users\\\\vikash_singh\\\\Desktop\\\\impqueries\\\\invoicesTesting\\\\testInv06.csv");
//		    InputStream targetStream = new FileInputStream(initialFile);
//    	    List<String> dataList = populateData(targetStream);

			deleteAllData();
			if (dataList.size() > 1) {
				saveCSVData(dataList, key);
			}
			LOG.info("Completed saving into db.");
		} catch (Exception e) {
			LOG.error("Exception Occured: " + e.getMessage());
		} finally {
			if (fullObject != null) {
				fullObject.close();
			}
			if (objectPortion != null) {
				objectPortion.close();
			}
			if (headerOverrideObject != null) {
				headerOverrideObject.close();
			}
		}
	}

	/**
	 * Convert the input stream into List<String>
	 * 
	 * @param input
	 * @return
	 * @throws IOException
	 */
	private List<String> populateData(InputStream input) throws IOException {
		List<String> content = new ArrayList<String>();
		BufferedReader reader = new BufferedReader(new InputStreamReader(input));
		String line = null;
		while ((line = reader.readLine()) != null) {
			content.add(line);
		}
		reader.close();
		LOG.info("total records count is: " + content.size());
		return content;
	}

	/**
	 * Persist the list of records into db
	 * 
	 * @param dataList
	 * @throws ParseException
	 */
	private void saveCSVData(List<String> dataList, String key) throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyMMdd");  //new date format is "yy-MM-dd 
		int exceptionCount = 0;
		List<String> exceptionRows = new ArrayList<>();
		List<Invoice> invoiceEntities = new ArrayList<Invoice>();
		int count1 = 1;
		while(dataList.size() > 0) {
		//for (String row : dataList) {
			String row = dataList.get(0);
			try {
				String fisherVendorName = row.length() > 9 ? row.substring(0, 10) : "";				
				String invoiceNumber = row.length() > 21 ? row.substring(10,22) : "";
				String invoiceDate = row.length() > 27 ? row.substring(22, 28) : "";
				String invoiceDescription = row.length() > 57 ? row.substring(28, 58) : "";
				String invoiceType = row.length() > 78 ? row.substring(58, 79) : "";
				String poNumber = row.length() > 108 ? row.substring(79, 109) : "";
				String invoiceStatus = row.length() > 109 ? row.substring(109, 110) : "";
				String invoiceAmount = row.length() > 121 ? row.substring(110, 122) : "";
				String invoiceAmountError = row.length() > 133 ? row.substring(122, 134) : "";
				String lineNumber = row.length() > 136 ? row.substring(134, 137) : "";
				String partNumber = row.length() > 148 ? row.substring(137, 149) : "";
				String vendorPartNumber = row.length() > 173 ? row.substring(149, 174) : "";
				String uom = row.length() > 179 ? row.substring(178, 180) : "";
				String orderQty = row.length() > 191 ? row.substring(180, 192) : "";
				String qtyReceived = row.length() > 203 ? row.substring(192, 204) : "";
				String qtyPreviouslyInvoiced = row.length() > 215 ? row.substring(204, 216) : "";
				String lineStatus = row.length() > 216 ? row.substring(216, 217) : "";
				String qtyInvoiced = row.length() > 228 ? row.substring(217, 229) : "";
				String lineAmountError = row.length() > 270 ? row.substring(257, 271) : "";
				String errorMessageConcat = row.length() > 275 ? row.substring(271, 276) : "" ;	
				String invoiceExpectedDate = row.length() > 281 ? row.substring(276, 282) : "" ;
				String invoicePaidDate = row.length() > 287 ? row.substring(282, 288) : "" ;
				String paymentTerm = row.length() > 363 ? row.substring(313, 364) : "" ;
     			String paymentNumber = row.length() > 299 ? row.substring(288, 300) : "" ;
     			//System.out.println(paymentNumber);
				
				 
				StringBuilder sb = new StringBuilder();

				InvoiceStaging entity = new InvoiceStaging();
				entity.setFisherVendorNumber(fisherVendorName.trim());
				entity.setInvoiceNumber(invoiceNumber.trim());

				if (invoiceDate.trim().length() > 0) {
					entity.setInvoiceDate(new Date(sdf.parse(invoiceDate.trim()).getTime()));
				}
				entity.setInvoiceDescription(invoiceDescription.trim());

				entity.setInvoiceType(
						Arrays.asList("S - STANDARD INVOICE", "C - CREDIT MEMO").contains(invoiceType.trim())
								? invoiceType.trim()
								: null);

				entity.setPoNumber(poNumber.trim());

				if (invoiceStatus.trim().length() > 0) {
					entity.setInvoiceStatus(
							invoiceStatusList.contains(invoiceStatus.trim()) ? invoiceStatus.trim().charAt(0) : null);
				}

				if (invoiceAmount.trim().length() > 0) {
					try {
						entity.setInvoiceAmount(new BigDecimal(invoiceAmount.trim().replaceAll("\\s", "")));
					} catch(Exception e) {
						sb.append("InvoiceAmount -" + e.getMessage());
					}
				}

				if (invoiceAmountError.trim().length() > 0) {
					try {
						entity.setInvoiceAmountError(new BigDecimal(invoiceAmountError.trim().replaceAll("\\s", "")));
					} catch(Exception e) {
						sb.append(", InvoiceAmountError -" + e.getMessage());
					}
				}

				if (lineNumber.trim().length() > 0) {
					entity.setLineNumber(Integer.valueOf(lineNumber.trim()));
				}

				entity.setPartNumber(partNumber.trim());
				entity.setVendorPartNumber(vendorPartNumber.trim());
				entity.setUom(uom.trim());

				if (orderQty.trim().length() > 0) {
					try {
						entity.setOrderQty(new BigDecimal(orderQty.trim().replaceAll("\\s", "")));
					} catch(Exception e) {
						sb.append(", OrderQty -" + e.getMessage());
					}
				}

				if (qtyReceived.trim().length() > 0) {
					try {
						entity.setQtyReceived(new BigDecimal(qtyReceived.trim().replaceAll("\\s", "")));
					} catch(Exception e) {
						sb.append(", QtyReceived -" + e.getMessage());
					}
				}

				if (qtyPreviouslyInvoiced.trim().length() > 0) {
					try {
						entity.setQtyPreviouslyInvoiced(new BigDecimal(qtyPreviouslyInvoiced.trim().replaceAll("\\s", "")));
					} catch(Exception e) {
						sb.append(", QtyPreviouslyInvoiced -" + e.getMessage());
					}
				}

				if (lineStatus.trim().length() > 0) {
					entity.setLineStatus(lineStatus.trim().charAt(0));
				}

				if (qtyInvoiced.trim().length() > 0) {
					try {
						entity.setQtyInvoiced(new BigDecimal(qtyInvoiced.trim().replaceAll("\\s", "")));
					} catch(Exception e) {
						sb.append(", QtyInvoiced -" + e.getMessage());
					}
				}
		
				if (lineAmountError.trim().length() > 0) {
					try {
						entity.setLineAmountError(new BigDecimal(lineAmountError.trim().replaceAll("\\s", "")));
					} catch(Exception e) {
						sb.append(", LineAmountError -" + e.getMessage());
					}
				}

				entity.setErrorMessageConcat(errorMessageConcat.trim());
				if (paymentTerm.trim().length() > 0) {
					entity.setPaymentTerm(paymentTerm.trim());
				}
				if (invoiceExpectedDate.trim().length() > 0) {
					entity.setInvoiceExpectedDate(new Date(sdf.parse(invoiceExpectedDate.trim()).getTime()));
				}
				if (invoicePaidDate.trim().length() > 0) {
					entity.setInvoicePaidDate(new Date(sdf.parse(invoicePaidDate.trim()).getTime()));
				}
				
				entity.setPaymentNumber(paymentNumber.trim());

				
				if(sb.length() > 0) {
					exceptionCount = exceptionCount + 1;
					exceptionRows.add(row + " -- " + sb.toString());
					if(exceptionCount > 5) {
						break;
					}
				} else {
					Optional<InvoiceStaging> e = Optional.ofNullable(invoiceStagingRepo.save(entity));
					if (e.isPresent()) {
						LOG.info("saved invoice in staging table with id: " + e.get().getId() + " adding to list of invoices");
						invoiceEntities.add(invoiceStagingToInvoice(entity));
					}
				}
				LOG.info(count1++);
				
			} catch (Exception ex) {
				LOG.error("Exception Occurred: " + ex.getMessage() + "\n in record: " + row);
				exceptionCount = exceptionCount + 1;
				exceptionRows.add(row + " -- " + ex.getMessage());
				LOG.info(count1++);
				if(exceptionCount > 5) {
					break;
				}
			}
			dataList.remove(0);
		}
		LOG.info("Completed inserting into statging db.");

		if (exceptionCount >= 0 && exceptionCount < 200) {
			int totalInvoiceEntities = invoiceEntities.size();
			LOG.info("inserting " + totalInvoiceEntities + " invoices in bi_invoices table");

			int batchSize = 3000;

			if (totalInvoiceEntities <= batchSize) {
				invoiceRepo.saveAll(invoiceEntities);
			} else {
				for(int i = 0; i < totalInvoiceEntities; i = i + batchSize) {
					if (i + batchSize < totalInvoiceEntities) {
						invoiceRepo.saveAll(invoiceEntities.subList(i, i + batchSize));
						LOG.info("Inserted " + (i + batchSize) + " records into DB"); 
					} else {
						invoiceRepo.saveAll(invoiceEntities.subList(i, totalInvoiceEntities));
					}
				}
			}
			deleteDuplicateData();
			mailUtil.sendSuccessMsg(key); // succes scenario
		} else {
			LOG.error("failed to save in bi_invoices table due to number of exceptions: " + exceptionCount);
			mailUtil.sendExceptionMsg(exceptionRows, key); // more exception scenario
		}
	}

	private Invoice invoiceStagingToInvoice(InvoiceStaging entity) {

		Invoice invoice = new Invoice();
		invoice.setFisherVendorNumber(entity.getFisherVendorNumber());
		invoice.setInvoiceNumber(entity.getInvoiceNumber());
		invoice.setInvoiceDescription(entity.getInvoiceDescription());
		invoice.setInvoiceType(Optional.ofNullable(entity.getInvoiceType()).isPresent() ? entity.getInvoiceType() : null);
		invoice.setPoNumber(entity.getPoNumber());
		invoice.setPartNumber(entity.getPartNumber());
		invoice.setVendorPartNumber(entity.getVendorPartNumber());
		invoice.setUom(entity.getUom());

		invoice.setInvoiceStatus(
				Optional.ofNullable(entity.getInvoiceStatus()).isPresent() ? entity.getInvoiceStatus() : null);

		if (Optional.ofNullable(entity.getInvoiceDate()).isPresent())
			invoice.setInvoiceDate(entity.getInvoiceDate());

		if (Optional.ofNullable(entity.getInvoiceAmount()).isPresent())
			invoice.setInvoiceAmount(entity.getInvoiceAmount());

		if (Optional.ofNullable(entity.getInvoiceAmountError()).isPresent())
			invoice.setInvoiceAmountError(entity.getInvoiceAmountError());

		if (Optional.ofNullable(entity.getLineNumber()).isPresent())
			invoice.setLineNumber(entity.getLineNumber());

		if (Optional.ofNullable(entity.getOrderQty()).isPresent())
			invoice.setOrderQty(entity.getOrderQty());

		if (Optional.ofNullable(entity.getQtyReceived()).isPresent())
			invoice.setQtyReceived(entity.getQtyReceived());
		
		if (Optional.ofNullable(entity.getQtyPreviouslyInvoiced()).isPresent())
			invoice.setQtyPreviouslyInvoiced(entity.getQtyPreviouslyInvoiced());

		if (Optional.ofNullable(entity.getLineStatus()).isPresent())
			invoice.setLineStatus(entity.getLineStatus());
		
		if (Optional.ofNullable(entity.getLineStatus()).isPresent())
			invoice.setLineStatus(entity.getLineStatus());
		
		if (Optional.ofNullable(entity.getQtyInvoiced()).isPresent())
			invoice.setQtyInvoiced(entity.getQtyInvoiced());

		if (Optional.ofNullable(entity.getLineAmountError()).isPresent())
			invoice.setLineAmountError(entity.getLineAmountError());
		
		if (Optional.ofNullable(entity.getErrorMessageConcat()).isPresent())
			invoice.setErrorMessageConcat(entity.getErrorMessageConcat());
		
		if (Optional.ofNullable(entity.getPaymentTerm()).isPresent())
			invoice.setPaymentTerm(entity.getPaymentTerm());
		
		if (Optional.ofNullable(entity.getInvoiceExpectedDate()).isPresent())
			invoice.setInvoiceExpectedDate(entity.getInvoiceExpectedDate());
		
		if (Optional.ofNullable(entity.getInvoicePaidDate()).isPresent())
			invoice.setInvoicePaidDate(entity.getInvoicePaidDate());
		
		if (Optional.ofNullable(entity.getPaymentNumber()).isPresent())
			invoice.setPaymentNumber(entity.getPaymentNumber());

		return invoice;
	}

	/**
	 * Delete all the records from db
	 */
	@Transactional
	@Modifying
	private void deleteAllData() {
		//invoiceStagingRepo.deleteAll();
		try {
			invoiceStagingRepo.truncateTable();
		} catch(Exception e) {
			LOG.info("deleted all the records.");
		}
		
	}
	
	@Transactional
	@Modifying
	private void deleteDuplicateData(){
	try {
		invoiceRepo.removeDuplicateFromTable();
		}
		catch(Exception e) {
			LOG.info("deleted all duplicate records.");
		}
	}
	
}
