package com.fishersci.supplierexchange.bi.api.mapper

import com.fishersci.supplierexchange.bi.api.model.InvoiceDTO
import com.fishersci.supplierexchange.bi.domain.Invoice
import lombok.extern.slf4j.Slf4j
import spock.lang.Specification
import static org.junit.Assert.assertEquals

@Slf4j
class InvoiceMapperSpec extends Specification {
    public static final String NAME = "Joe"
    public static final long ID = 1L

    InvoiceMapper invoiceMapper = InvoiceMapper.INSTANCE

    def "invoiceToInvoiceDTO() maps category domain to categoryDTO"() {
        given:
            Invoice invoice = new Invoice()
            invoice.setFisherVendorNumber(NAME)
            invoice.setId(ID)

        when:
            InvoiceDTO invoiceDTO = invoiceMapper.invoiceToInvoiceDTO(invoice)

        then:

            assertEquals(Long.valueOf(ID), invoiceDTO.getId())
            assertEquals(NAME, invoiceDTO.getFisherVendorNumber())
    }
}
