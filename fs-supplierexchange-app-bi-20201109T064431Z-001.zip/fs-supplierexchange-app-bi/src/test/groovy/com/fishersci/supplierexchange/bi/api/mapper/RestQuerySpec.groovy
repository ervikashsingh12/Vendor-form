package com.fishersci.supplierexchange.bi.api.mapper

import com.fishersci.supplierexchange.bi.services.JWTService
import io.jsonwebtoken.JwtBuilder
import io.jsonwebtoken.Jwts
import io.jsonwebtoken.SignatureAlgorithm
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Value
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.test.context.ContextConfiguration
import spock.lang.Specification
import com.fishersci.supplierexchange.bi.api.filters.JWTFilter
import org.springframework.web.context.WebApplicationContext
import org.springframework.test.web.servlet.MockMvc
import org.springframework.test.web.servlet.setup.MockMvcBuilders
import spock.lang.Unroll

import java.nio.charset.StandardCharsets

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*

@ContextConfiguration
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.MOCK)
class RestQuerySpec extends Specification {
    @Autowired
    WebApplicationContext webApplicationContext
    @Autowired
    JWTFilter filter
    @Autowired
    JWTService jtwService

    MockMvc mockMvc

    @Value('${jwt.test}')
    private String validToken

    @Value('${jwt.secret}')
    private String tokenKey



    def setup() {
        mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).addFilter(filter).build()
    }

    def "Api should be accessible for user with valid JWT"(){
        given:
            String validBearerToken = "Bearer " + validToken

        when:
            def validResponse = mockMvc.perform(get("http://localhost:8080/invoices")
                .header("Authorization", validBearerToken))

            def noJWTResponse = mockMvc.perform(get("http://localhost:8080/invoices")
                )

        then:
            validResponse.andExpect(status().isOk())
            noJWTResponse.andExpect(status().is(401))
    }

    @Unroll
    def "I am from regions = #regions and my supplierAliases = #supplierAliases"(){
        given:
        Map userInfo = jtwService.generateSampleClaims(supplierAliases,regions)
        JwtBuilder builder = Jwts.builder()
        builder.setClaims(userInfo)
        String jwt = builder.signWith(SignatureAlgorithm.HS512, tokenKey.getBytes(StandardCharsets.UTF_8)).compact()
        String bearerToken = "Bearer " + jwt
        def response = mockMvc.perform(get("http://localhost:8080/invoices")
                .header("Authorization", bearerToken))
        expect:
            response.andExpect(content().json("{page: { totalElements: " + numberOfRows + " } }"))
        where:
        regions | supplierAliases | numberOfRows
        ["NA"] | ["VN00000003"] | 139
        ["NA"] | ["VN00052377", "VN00000003"] | 2794
        ["NA"] | ["VN00008871"] | 41783
        ["EU"] | ["VN00008871"] | 0
        ["NA","EU"] | ["VN00008871"] | 41783
    }

    @Unroll
    def "the system should return the correct results when receiving a search query"(){
        given:
        Map userInfo = jtwService.generateSampleClaims(supplierAliases,regions)
        JwtBuilder builder = Jwts.builder()
        builder.setClaims(userInfo)
        String jwt = builder.signWith(SignatureAlgorithm.HS512, tokenKey.getBytes(StandardCharsets.UTF_8)).compact()
        String bearerToken = "Bearer " + jwt

        def queryParameters = ""
        if (fuzzyNumber != ""){queryParameters += "fuzzyNumber=${fuzzyNumber}&"}
        if (invoiceDate != ""){queryParameters += "invoiceDate=${invoiceDate}&"}
        if (invoiceType != ""){queryParameters += "invoiceType=${invoiceType}&"}
        if (invoiceStatus != ""){queryParameters += "invoiceStatus=${invoiceStatus}&"}
        if (errorMessageConcat != ""){queryParameters += "errorMessageConcat=${errorMessageConcat}&"}

        def response = mockMvc.perform(get("http://localhost:8080/invoices/search/searchCriteria?${queryParameters}")
                .header("Authorization", bearerToken))

        expect:
        response.andExpect(content().json("{page: { totalElements: " + numberOfRows + " } }"))

        where:

        regions | supplierAliases              | numberOfRows | fuzzyNumber  | invoiceDate  | invoiceType            | invoiceStatus | errorMessageConcat
        ["NA"]  | ["VN00002363", "VN00002607"] | 6            | "VN00002363" | "2017-05-02" | "S - STANDARD INVOICE" | "E"           | "3"

    }

    @Unroll
    def "the system should return a csv file with correct header row"(){
        given:
        Map userInfo = jtwService.generateSampleClaims(supplierAliases,regions)
        JwtBuilder builder = Jwts.builder()
        builder.setClaims(userInfo)
        String jwt = builder.signWith(SignatureAlgorithm.HS512, tokenKey.getBytes(StandardCharsets.UTF_8)).compact()
        String bearerToken = "Bearer " + jwt

        def response = mockMvc.perform(get("http://localhost:8080/invoices/export")
                .header("Authorization", bearerToken))

        expect:
        response.andExpect(content().contentType("text/plain;charset=UTF-8"))

        where:

        regions | supplierAliases              | numberOfRows | fuzzyNumber  | invoiceDate  | invoiceType            | invoiceStatus | errorMessageConcat
        ["NA"]  | ["VN00002363", "VN00002607"] | 6            | "VN00002363" | "2017-05-02" | "S - STANDARD INVOICE" | "E"           | "3"

    }

}
