package com.example.test.cts.demotest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemotestApplicationTests {

	@Test
	void contextLoads() {
	}

}
